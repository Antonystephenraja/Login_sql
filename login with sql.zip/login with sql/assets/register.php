<?php
if(isset($_POST['Uname']) && isset($_POST['Uname'])){
    function validation($data){
        $data=trim($data);
        $data=stripslashes($data);
        $data=htmlspecialchars($data);
        return $data;
    }
}
$n=validation($_POST['Uname']);
$c=validation($_POST['Pass']);
$con=mysqli_connect("localhost","root","","test");
$sql="INSERT INTO register2(Username,password) values('$n','$c')";
$r=mysqli_query($con,$sql);
if($r)
{
    echo "STUDENT DETAILS ADDED SUCCESSFULLY";
}
else{
    echo "STUDENT DETAILS NOT ADDED";
}
?>